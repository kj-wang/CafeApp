package com.example.project5;

import android.os.Bundle;

import android.widget.*; //i dont think we can dooooooooooooooooo this

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.snackbar.Snackbar;

import java.text.DecimalFormat;

/**
 * This controller supports functions for the donut activity and allows addition of donuts to the current order
 *
 *
 * @author KJ Wang, Mehdi Kamal
 */
public class donutController extends AppCompatActivity implements AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener {
    private Donut donut;
    private Button addToOrder;
    private Spinner donutQuantity;
    private Spinner donutFlavor;

    /**
     * This method is used to update the gui
     * @param savedInstanceState the instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donut);


        //listener for donutflavor
        Spinner donutFlavor = (Spinner) findViewById(R.id.donutFlavorSpinner);
        donutFlavor.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);//why do i have to cast

        //listener for quantity
        donutQuantity= (Spinner) findViewById(R.id.donutQuantitySpinner);
        donutQuantity.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);


        //listener for add to order button
        addToOrder = (Button) findViewById(R.id.donutAddToOrderButton);
        addToOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToOrder();
            }
        });

        //initial update
        subtotal();

        Toolbar toolbar = findViewById(R.id.donutToolbar);
        toolbar.setTitle(R.string.donut_label);
    }


    /**
     * Method that updates the current donut when quantity or flavor spinner is changed
     * @param parent the parent adapter
     * @param arg1 the view
     * @param pos the position integer
     * @param id the id
     */
    @Override
    public void onItemSelected(AdapterView<?> parent, View arg1, int pos,long id) {
        //update subtotal based on quant
        //if (donutFlavor.getSelectedItem() != null) {
            subtotal();
    }

    /**
     * This method is utilized for the customizable interface
     * @param arg0 the adapterview
     */
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }



    /**
     * this method sets the flavor of the donut object when a flavor is selected
     * @param parent the parent adapter
     * @param view the view
     * @param position the position integer
     * @param id the id
     */
    public void onItemClick(AdapterView<?> parent, View view, int position, long id){
        //if flavor is selected, update object flavor
            donut.setFlavor(donutFlavor.getSelectedItem().toString());
    }

    /**
     * This method adds a specific donut object to the Order
     */
    private void addToOrder() {
        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.donutLayout), R.string.confirm_label, Snackbar.LENGTH_INDEFINITE);
        mySnackbar.setAction(android.R.string.ok, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                donutCreator();
                donut.itemPrice();
                //subtotal();                           // might not need this one
                //adds donut to universal order
                MainActivity.order.add(donut);
                Toast.makeText(getApplicationContext(), R.string.order_placed_label, Toast.LENGTH_SHORT).show();
            }
        });
        mySnackbar.show();

        System.out.println("added out here");
        System.out.println(MainActivity.order.exportDatabase());

    }

    /**
     * This method updates the current subtotal text field based on quantity of donuts
     */
    private void subtotal() {
        double subtotal = 0.0;

        //dynamically update based on current comboboxes
        donutCreator();

        donut.itemPrice();
        subtotal = donut.getPrice();

        //formatting for subtotal
        DecimalFormat dec = new DecimalFormat("$###,###,###,##0.00");
        String subtotalString = (String) dec.format(subtotal);

        //update subtotal on gui
        TextView subtotalView = (TextView) findViewById(R.id.donutSubtotalButton);
        subtotalView.setText(subtotalString);
    }

    /**
     * THis method creates a donut object to be added to Order
     */
    private void donutCreator(){
        donut = new Donut();

        // set buttons
        donutQuantity = (Spinner) findViewById(R.id.donutQuantitySpinner);
        donutFlavor = (Spinner) findViewById(R.id.donutFlavorSpinner);

        //SET QUANTITY
        String quantityString = donutQuantity.getSelectedItem().toString();
        int quantityNum = Integer.parseInt(quantityString);
        donut.setQuantity(quantityNum);

        //SET FLAVOR
        donut.setFlavor(donutFlavor.getSelectedItem().toString());

        //calculate price
        donut.itemPrice();
    }

}