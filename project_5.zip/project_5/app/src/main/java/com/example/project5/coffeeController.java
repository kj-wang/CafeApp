package com.example.project5;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.AdapterView.OnItemSelectedListener;

import android.view.View;

import java.text.DecimalFormat;

/**
 * This controller controls the activity for coffee and creates functions for the buttons
 *
 *
 * @author KJ Wang, Mehdi Kamal
 */
public class coffeeController extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Spinner coffeeQuantity;
    private Spinner coffeeSize;
    private CheckBox milk;
    private CheckBox cream;
    private CheckBox whippedCream;
    private CheckBox caramel;
    private CheckBox syrup;
    private Button addToOrder;

    private Coffee coffee;

    /**
     * initializes the window and updates the gui with information
     * @param savedInstanceState the instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffee);

        //get all the buttons
        milk = (CheckBox) findViewById(R.id.milkbutton);
        cream = (CheckBox) findViewById(R.id.creambutton);
        whippedCream = (CheckBox) findViewById(R.id.whippedcreambutton);
        caramel = (CheckBox) findViewById(R.id.caramelbutton);
        syrup = (CheckBox) findViewById(R.id.syrupbutton);
        addToOrder =  (Button)findViewById(R.id.coffeeAddToOrderButton);


        //If quantity is clicked, update subtotal
        coffeeQuantity = (Spinner) findViewById(R.id.coffeeQuantitySpinner);
        coffeeQuantity.setOnItemSelectedListener((OnItemSelectedListener) this);//why do i have to cast


        //if size is clicked, update subtotal
        coffeeSize= (Spinner) findViewById(R.id.coffeeSizeSpinner);
        coffeeSize.setOnItemSelectedListener((OnItemSelectedListener) this);

        //listener for the buttons
        addToOrder = (Button) findViewById(R.id.coffeeAddToOrderButton);
        addToOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToOrder();
            }
        });


        milk.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                subtotal();
            }
        });

        cream.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                subtotal();
            }
        });

        whippedCream.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                subtotal();
            }
        });

        caramel.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                subtotal();
            }
        });

        syrup.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                subtotal();
            }
        });

        //initial call
        subtotal();

        Toolbar toolbar = findViewById(R.id.coffeeToolbar);
        toolbar.setTitle(R.string.coffee_label);
    }


    /**
     * Method that updates the current coffee object when quantity or size are changed
     * @param parent the parent adapter
     * @param arg1 the view
     * @param pos the position
     * @param id the id
     */
    @Override
    public void onItemSelected(AdapterView<?> parent, View arg1, int pos,long id) {
         subtotal();
    }

    /**
     * This method is utilized for the customizable interface
     * @param arg0
     */
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    /**
     * This method is used to add the current coffee object to order
     */
    public void addToOrder(){

        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.coffeeLayout), R.string.confirm_label, Snackbar.LENGTH_INDEFINITE);
        mySnackbar.setAction(android.R.string.ok, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                coffeeCreator();
                coffee.itemPrice();
                //adds coffee to universal order
                MainActivity.order.add(coffee);
                Toast.makeText(getApplicationContext(), R.string.order_placed_label, Toast.LENGTH_SHORT).show();

            }
        });
        mySnackbar.show();
    }

    /**
     * This method is used to calculate the subtotal of the current coffee order
     */
    private void subtotal() { //assigned to the spinners and all the checkboxes

        //new coffee object
        coffeeCreator();

        //subtotal calculation
        double subtotalDouble = 0.0;
        coffee.itemPrice();
        subtotalDouble = coffee.getPrice();

        //formatting for subtotal
        DecimalFormat dec = new DecimalFormat("$###,###,###,##0.00");
        String subtotalString = (String) dec.format(subtotalDouble);

        //update subtotal on gui
        TextView subtotalView = (TextView) findViewById(R.id.coffeeSubtotalButton);
        subtotalView.setText(subtotalString);
    }

    /**
     * This method creates a coffee object to be added to the order
     */
    private void coffeeCreator(){
        coffee = new Coffee();

        //retrieve button
        whippedCream = (CheckBox) findViewById(R.id.whippedcreambutton);
        milk = (CheckBox) findViewById(R.id.milkbutton);
        cream = (CheckBox) findViewById(R.id.creambutton);
        syrup = (CheckBox) findViewById(R.id.syrupbutton);
        caramel = (CheckBox) findViewById(R.id.caramelbutton);

        //ADD-INS
        if (whippedCream.isChecked()){
            coffee.add("whippedCream");
        }
        else {
            coffee.remove("whippedCream");
        }
        if (milk.isChecked()) {
            coffee.add("milk");
        }
        else {
            coffee.remove("milk");
        }
        if (cream.isChecked()) {
            coffee.add("cream");
        }
        else {
            coffee.remove("cream");
        }
        if (syrup.isChecked()) {
            coffee.add("syrup");
        }
        else {
            coffee.remove("syrup");
        }
        if (caramel.isChecked()) {
            coffee.add("caramel");
        }
        else {
            coffee.remove("caramel");
        }

        //Set quantity
        String quantityString = coffeeQuantity.getSelectedItem().toString();
        int quantityNum = Integer.parseInt(quantityString);
        coffee.setQuantity(quantityNum);

        //Set Size
        coffee.setSize((String) coffeeSize.getSelectedItem().toString());
    }
}