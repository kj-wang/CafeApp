package com.example.project5;

import java.text.DecimalFormat;


/**
 * This class extends the menuItem class and includes specific data and operations specific to donut
 *
 * @author KJ Wang, Mehdi Kamal
 */
public class Donut extends RUMenuItem {
    private String flavor;
    private static final int INIT_QUANTITY = 1;
    private static final double DONUT_PRICE = 1.39;

    /**
     * This method is a constructor for donut
     */
    public Donut() {
        super.setQuantity(INIT_QUANTITY);
    }

    /**
     * This method is a contructor for donut
     * @param flavor flavor of donut
     */
    public Donut(String flavor) {
        this.flavor = flavor;
        super.setQuantity(INIT_QUANTITY);

    }


    /**
     * This is a setter for the donut flavor
     * @param flavor flavor of donut
     */
    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }


    /*
     * This calculates the price of a donut object based on the quantity
     */
    @Override
    public void itemPrice() {
        double price = DONUT_PRICE;
        price = price * super.getQuantity();
        super.setPrice(price);
    }

    /**
     * Compares an object to a donut to see if they are equal
     * @param obj object to be compared to given donut
     * @return true if equal, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Donut) {
            Donut temp = (Donut) obj;
            //checks to see if same flavor
            if(temp.flavor.equals(flavor)) {
                return true;
            }
        }
        return false;
    }


    /**
     * This method returns a textual representation of a fulltime employees profile, payment, and annual salary
     * @return String a textual representation
     */
    @Override
    public String toString() {
        DecimalFormat dec = new DecimalFormat("$###,###,###,##0.00");
        String textualRepresentation = ( "donut::flavor::" + flavor + "::price " + dec.format(super.getPrice()) + "::quantity " + super.getQuantity());
        return textualRepresentation;
    }

}
