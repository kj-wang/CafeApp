package com.example.project5;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

/**
 * This controller creates buttons for the other activities to be created and changed as needed
 *
 *
 * @author KJ Wang, Mehdi Kamal
 */
public class MainActivity extends AppCompatActivity {
    public static Order order = new Order(); //global order
    public static StoreOrders storeOrders = new StoreOrders();

    /**
     * This method opens the donut activity
     * @param view the current view
     */
    public void openDonut(View view) {
        Intent intent = new Intent(this, donutController.class);
        // intent extra something (Order order)
        startActivity(intent);
    }

    /**
     * This method opens the coffee activity
     * @param view the current view
     */
    public void openCoffee(View view) {
        Intent intent = new Intent(this, coffeeController.class);
        startActivity(intent);
    }

    /**
     * This method opens the current order activity
     * @param view the current view
     */
    public void openCurrentOrder(View view) {
        Intent intent = new Intent(this, currentOrderController.class);
        startActivity(intent);
    }

    /**
     * This method opens the store orders activity
     * @param view the current view
     */
    public void openStoreOrders(View view) {
        Intent intent = new Intent(this, storeOrderController.class);
        startActivity(intent);
    }

    /**
     * This method updates the gui for this activity
     * @param savedInstanceState the instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.mainToolbar);
        toolbar.setTitle(R.string.app_name);
    }
}
