package com.example.project5;

import android.os.Bundle;
import java.util.ArrayList;

import android.widget.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.MenuItem;

import java.text.DecimalFormat;
import java.util.StringTokenizer;

/**
 * This controller controls for the current order and updates it as well as exports it to storeOrders
 *
 *
 * @author KJ Wang, Mehdi Kamal
 */
public class currentOrderController extends AppCompatActivity implements AdapterView.OnItemClickListener{

    private static final double SALES_TAX = .06625;
    private Button currentOrderPlaceOrderButton;
    private int numOrders;
    private ListView itemList;
    public static final int NO_ORDERS = 0;

    /**
     * This method is used to update the gui
     * @param savedInstanceState the instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currentorder);

        itemList = (ListView) findViewById(R.id.currentOrderView);
        itemList.setOnItemClickListener((AdapterView.OnItemClickListener) this);

        //listener for placeorder button
        currentOrderPlaceOrderButton = (Button) findViewById(R.id.currentOrderPlaceOrderButton);
        currentOrderPlaceOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeOrder();
            }
        });

        initializeOrder();

        //notifation for how to cancel
        Toast.makeText(getApplicationContext(), R.string.how_to_remove_label, Toast.LENGTH_LONG).show();

        Toolbar toolbar = findViewById(R.id.currentOrderToolbar);
        toolbar.setTitle(R.string.current_order_label);

    }

    /**
     * This method is run when a line is clicked within the listview
     * @param parent the parent adapter
     * @param view the view
     * @param position the position
     * @param id the id
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        try {
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setMessage(R.string.confirm_label).setTitle(R.string.remove_selected_item_label);
            alert.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    //the string to be removed
                    String removedItem = itemList.getItemAtPosition(position).toString();
                    //remove
                    remove(position, removedItem);
                    //refresh page
                    initializeOrder();
                    //throw alert
                    Toast.makeText(getApplicationContext(), R.string.removed_label, Toast.LENGTH_SHORT).show();
                }
            });
            alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            AlertDialog dialog = alert.create();
            dialog.show();
        } catch (Exception e) {
        }
    }


    /**
     * This function initializes the order and refreshes the page based on the order
     */
    private void initializeOrder() {
        //import number of MenuItems and the MenuItems
        int numItems = MainActivity.order.getNumItems();

        //checks to see if order is blank, disables addtoorderbutton
        if (numItems == NO_ORDERS) {
            //disable
            currentOrderPlaceOrderButton.setEnabled(false);
        }
        else {
            //enable
            currentOrderPlaceOrderButton.setEnabled(true);
        }

            RUMenuItem[] traverseList =  MainActivity.order.getOrder();

            // Arraylist of items from order
            ArrayList<String> list = new ArrayList<String>();
            for (int i = 0; i < numItems; i++) {
                list.add(traverseList[i].toString());
            }

            //Fill listview with items
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);          // may not need to clear bc new adapter

            //clear first
            itemList.setAdapter(arrayAdapter);


            //initialize subtotal
            subtotal();
    }

    /**
     * This function updates StoreOrders and clears the current order
     */
    private void placeOrder() {

        Snackbar mySnackbar = Snackbar.make(findViewById(R.id.currentOrderLayout), R.string.confirm_label, Snackbar.LENGTH_INDEFINITE);
        mySnackbar.setAction(android.R.string.ok, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.storeOrders.add(MainActivity.order);
                MainActivity.order = new Order();
                initializeOrder();
                Toast.makeText(getApplicationContext(), R.string.order_placed_label, Toast.LENGTH_LONG).show();
            }
        });
        mySnackbar.show();

    }

    /**
     * This method removes a specific menuItem from the current order
     * @param position the position
     * @param removedItem the item to be removed
     */
    private void remove(int position, String removedItem) {

        StringTokenizer st = new StringTokenizer(removedItem, "::");

        //Remove coffee
        String menuItemType = st.nextToken();
        if (menuItemType.equals("coffee")) {
            st.nextToken();
            String size = st.nextToken().trim();

            //Coffee to be removed
            Coffee temp = new Coffee(size);

            st.nextToken(); //skip price and price value
            st.nextToken(); //skip quantity and quantity value

            //add addins coffee object
            while (st.hasMoreTokens()) {
                String addins = st.nextToken().trim();
                temp.add(addins);
            }

            MainActivity.order.remove(temp);

        }

        //REMOVE DONUT
        else if (menuItemType.equals("donut")) {
            st.nextToken();
            String flavorToken = st.nextToken();
            Donut temp = new Donut(flavorToken);

            MainActivity.order.remove(temp);
        }

        //refresh page
        initializeOrder();
    }

    /**
     * This function updates the subtotal, sales tax, and total text areas
     *
     */
    private void subtotal() {
        double subtotal = MainActivity.order.calculate();

        //update subtotal gui
        TextView subtotalView = (TextView) findViewById(R.id.currentOrderSubtotalButton);

        DecimalFormat dec = new DecimalFormat("$###,###,###,##0.00");
        String subtotalString = dec.format(subtotal);
        subtotalView.setText(subtotalString);


        //SALES TAX
        TextView salesTaxView = (TextView) findViewById(R.id.salesTaxButton);
        double salesTax = subtotal * SALES_TAX;
        String salesTaxString = dec.format(salesTax);
        salesTaxView.setText(salesTaxString);

        //TOTAL
        TextView totalView = (TextView) findViewById(R.id.currentOrderTotalButton);
        double total = subtotal + salesTax;
        String totalString = dec.format(total);
        totalView.setText(totalString);
    }

}