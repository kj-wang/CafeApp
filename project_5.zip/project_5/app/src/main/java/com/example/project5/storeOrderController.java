package com.example.project5;

import android.os.Bundle;

import android.widget.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import org.w3c.dom.Text;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * This controller supports the functions for store orders by listing all the orders in a spinner and giving the option to cancel
 *
 *
 * @author KJ Wang, Mehdi Kamal
 */
public class storeOrderController extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private int numOrders;
    private Order selectedOrder;
    private static final double SALES_TAX = 0.06625;
    private ListView orderList;
    private Spinner orderNumberSpinner;
    private Button cancelOrderButton;
    private TextView totalView;
    public static final String NO_ORDER_COST = "0.00";
    public static final int NO_ORDERS = 0;


    /**
     * This method is used to update the gui
     * @param savedInstanceState the instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storeorders);

        //orderList getter
        orderList = (ListView) findViewById(R.id.storeOrderView);

        totalView = (TextView) findViewById(R.id.storeOrderTotalView);

        //listener for orderNumber
        orderNumberSpinner = (Spinner) findViewById(R.id.orderNumberSpinner);
        orderNumberSpinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);

        //listener for cancel order button
        cancelOrderButton = (Button) findViewById(R.id.storeOrdersCancelButton);
        cancelOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedOrderNumberString = orderNumberSpinner.getSelectedItem().toString();
                int selectedOrderNumber = Integer.parseInt(selectedOrderNumberString);
                cancelOrder(selectedOrderNumber);
            }
        });

        initializeStoreOrders();

        Toolbar toolbar = findViewById(R.id.storeOrdersToolbar);
        toolbar.setTitle(R.string.store_order_label);
    }

     /**
     * This method is used to update the listview based on currently selected order
     * @param parent the parent adapterview
     * @param arg1 the view
     * @param pos the position
     * @param id the id
     */
    @Override
    public void onItemSelected(AdapterView<?> parent, View arg1, int pos,long id) {
        orderViewUpdater();
    }

    /**
     * This method is used to implement the interface
     * @param arg0 the adapterview
     */
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }


    /**
     * This method updates the visuals based on what is in StoreOrders
     */
    private void initializeStoreOrders(){
        //import number of MenuItems and the MenuItems
        numOrders = MainActivity.storeOrders.getNumOrders();

        //checks to see if no orders , disables cancel button
        if (numOrders == NO_ORDERS) {
            //disable
            cancelOrderButton.setEnabled(false);
        }
        else {
            //enable
            cancelOrderButton.setEnabled(true);
        }

        //update spinner
        if (numOrders > NO_ORDERS) {
            ArrayList<Integer> list = new ArrayList<Integer>();
            for (int i = 0; i < numOrders; i++) {
                list.add(i);
            }

            ArrayAdapter<Integer> arrayAdapter = new ArrayAdapter<Integer>(this, android.R.layout.simple_list_item_1, list);          // may not need to clear bc new adapter
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            orderNumberSpinner.setAdapter(arrayAdapter);
        }
    }

    /**
     * This method updates the listview
     */
    private void orderViewUpdater(){
        //gets selected order
        numOrders = MainActivity.storeOrders.getNumOrders();
        ArrayList<String> list = new ArrayList<String>();

        if (numOrders > NO_ORDERS) {
            Order[] traverseList = MainActivity.storeOrders.getStoreOrders();
            String chosenOrderString = orderNumberSpinner.getSelectedItem().toString();
            int chosenOrderNumber = Integer.parseInt(chosenOrderString);
            selectedOrder = traverseList[chosenOrderNumber];
            RUMenuItem[] listItems = selectedOrder.getOrder();
            int numItems = selectedOrder.getNumItems();

            // Arraylist of items from chosen order
            for (int i = 0; i < numItems; i++) {
                list.add(listItems[i].toString());
            }
        }

        //Fill listview with items
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);          // may not need to clear bc new adapter

        //update listview
        ListView storeOrderView = (ListView) findViewById(R.id.storeOrderView);
        storeOrderView.setAdapter(arrayAdapter);

        total();
    }


    /**
     * This method cancels a selected order from storeOrders
     * @param orderNumber order number
     */
    private void cancelOrder(int orderNumber) {
        //int orderNumber = (int) orderNumberButton.getValue();

        //list of orders
        Order[] traverseList = MainActivity.storeOrders.getStoreOrders();
        //selected order and length
        selectedOrder = traverseList[orderNumber];

        MainActivity.storeOrders.remove(selectedOrder);

        numOrders = MainActivity.storeOrders.getNumOrders();

        //removes from combobox
        orderNumberSpinner.setAdapter(null);
        initializeStoreOrders();
        orderViewUpdater();
    }

    /**
     * This function calculates the total to be displayed and updates the textbox
     */
    private void total() {

        numOrders = MainActivity.storeOrders.getNumOrders();

        if (numOrders > NO_ORDERS) {
            double subtotal = selectedOrder.calculate();
            double salesTax = subtotal * SALES_TAX;
            double total = subtotal + salesTax;

            //formatting
            DecimalFormat dec = new DecimalFormat("$###,###,###,##0.00");
            String totalString = dec.format(total);
            totalView.setText(totalString);
        } else {
            totalView.setText(NO_ORDER_COST);
        }
    }
}